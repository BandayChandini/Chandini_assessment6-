function squareNumbers(numbers) {
    // Use the map function to square each number
    return numbers.map(number => number * number);
}

// Example usage:
const numbersArray = [1, 2, 3, 4, 5];
const squaredArray = squareNumbers(numbersArray);

console.log(squaredArray);
