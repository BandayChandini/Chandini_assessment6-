﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment6
{
    using System;
    using System.Linq; // For LINQ methods

    class ArrayOperations
    {
        static void Main()
        {
            // Define an array of integers
            int[] numbers = { 5, 10, 15, 20, 25, 30 };

            // Find the sum of all elements
            int sum = numbers.Sum();

            // Find the average of all elements
            double average = numbers.Average();

            // Find the maximum value
            int max = numbers.Max();

            // Find the minimum value
            int min = numbers.Min();

            // Display the results
            Console.WriteLine("Array: " + string.Join(", ", numbers));
            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Average: {average}");
            Console.WriteLine($"Maximum: {max}");
            Console.WriteLine($"Minimum: {min}");

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }

    
}
