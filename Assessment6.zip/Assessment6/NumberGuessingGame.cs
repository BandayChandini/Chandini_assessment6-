﻿namespace Assessment6
{
    using System;

    class NumberGuessingGame
    {
        static void Main()
        {
            // Set the range and the number of attempts
            int minRange = 1;
            int maxRange = 100;
            int maxAttempts = 10;

            // Create a random number generator
            Random random = new Random();
            int numberToGuess = random.Next(minRange, maxRange + 1);

            Console.WriteLine("Welcome to the Number Guessing Game!");
            Console.WriteLine($"Guess the number between {minRange} and {maxRange}.");
            Console.WriteLine($"You have {maxAttempts} attempts to guess the number.");

            int attemptsLeft = maxAttempts;
            bool isGuessedCorrectly = false;

            while (attemptsLeft > 0)
            {
                try
                {
                    Console.Write($"Enter your guess (Attempts left: {attemptsLeft}): ");
                    string input = Console.ReadLine();

                    // Convert the input to an integer
                    int userGuess = int.Parse(input);

                    if (userGuess == numberToGuess)
                    {
                        Console.WriteLine("Congratulations! You've guessed the number correctly.");
                        isGuessedCorrectly = true;
                        break;
                    }
                    else if (userGuess < numberToGuess)
                    {
                        Console.WriteLine("The Guessed number is higher. Try again.");
                    }
                    else
                    {
                        Console.WriteLine("The Guessed number is lower. Try again.");
                    }

                    attemptsLeft--;
                }
                catch (FormatException)
                {
                    // Handle invalid input format
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
            }

            if (!isGuessedCorrectly)
            {
                Console.WriteLine($"Sorry, you've run out of attempts. The number was {numberToGuess}.");
            }

            Console.WriteLine("Game over. Press any key to exit.");
            Console.ReadKey();
        }
    }

    
}
