function filterOddNumbers(numbers) {
    // Use the filter method to keep only odd numbers
    return numbers.filter(number => number % 2 !== 0);
}

// Example usage:
const numbersArray = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const oddNumbers = filterOddNumbers(numbersArray);

console.log(oddNumbers); // Output: [1, 3, 5, 7, 9]
